<?php

namespace App\Http\Controllers\Web;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Display the homepage
     */
    public function index()
    {
        // Eng ko'p sotilgan mahsulotlar
        $bestSellers = Product::where('is_active', true)
            ->orderBy('view_count', 'desc')
            ->limit(8)
            ->get();

        // Yangi mahsulotlar
        $newProducts = Product::where('is_active', true)
            ->orderBy('created_at', 'desc')
            ->limit(8)
            ->get();

        // Aksiya mahsulotlari (chegirmada)
        $saleProducts = Product::where('is_active', true)
            ->whereNotNull('sale_price')
            ->where('sale_price', '>', 0)
            ->limit(8)
            ->get();

        // Asosiy kategoriyalar
        $categories = Category::where('is_active', true)
            ->whereNull('parent_id')
            ->limit(8)
            ->get();

        return view('web.index', compact(
            'bestSellers',
            'newProducts',
            'saleProducts',
            'categories'
        ));
    }

    /**
     * Search products
     */
    public function search(Request $request)
    {
        $query = $request->get('q');
        $categoryId = $request->get('category');
        $sort = $request->get('sort', 'relevance');
        $perPage = $request->get('per_page', 20);

        $products = Product::where('status', 'active');

        // Qidiruv bo'yicha filter
        if ($query) {
            $currentLocale = app()->getLocale();
            $products->where(function($q) use ($query, $currentLocale) {
                $q->where("name->{$currentLocale}", 'LIKE', "%{$query}%")
                  ->orWhere("description->{$currentLocale}", 'LIKE', "%{$query}%")
                  ->orWhere('sku', 'LIKE', "%{$query}%");
            });
        }

        // Kategoriya bo'yicha filter
        if ($categoryId) {
            $products->where('category_id', $categoryId);
        }

        // Saralash
        switch ($sort) {
            case 'price_low':
                $products->orderBy('price', 'asc');
                break;
            case 'price_high':
                $products->orderBy('price', 'desc');
                break;
            case 'newest':
                $products->orderBy('created_at', 'desc');
                break;
            case 'popular':
                $products->orderBy('view_count', 'desc');
                break;
            default:
                $products->orderBy('created_at', 'desc');
        }

        $products = $products->paginate($perPage);
        $categories = Category::where('status', 'active')->get();

        return view('web.search', compact('products', 'categories', 'query', 'categoryId', 'sort'));
    }

    /**
     * About page
     */
    public function about()
    {
        return view('web.about');
    }

    /**
     * Contact page
     */
    public function contact()
    {
        return view('web.contact');
    }

    /**
     * Terms page
     */
    public function terms()
    {
        return view('web.terms');
    }

    /**
     * Privacy page
     */
    public function privacy()
    {
        return view('web.privacy');
    }

    /**
     * Subscribe to newsletter
     */
    public function subscribeNewsletter(Request $request)
    {
        $request->validate([
            'email' => 'required|email|unique:newsletter_subscriptions,email'
        ]);

        try {
            // Newsletter subscription logic here
            // For now, just return success

            return response()->json([
                'success' => true,
                'message' => 'Muvaffaqiyatli obuna bo\'ldingiz!'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Xatolik yuz berdi. Qaytadan urinib ko\'ring.'
            ], 500);
        }
    }
}
